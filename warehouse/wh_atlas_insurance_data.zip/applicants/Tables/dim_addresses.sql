CREATE TABLE [applicants].[dim_addresses] (

	[address_sk] bigint NULL, 
	[applicant_id] varchar(max) NULL, 
	[street_address] varchar(max) NULL, 
	[city] varchar(max) NULL, 
	[province] varchar(max) NULL, 
	[postal_code] bigint NULL, 
	[is_current] bigint NULL, 
	[load_timestamp] datetime2(6) NOT NULL
);