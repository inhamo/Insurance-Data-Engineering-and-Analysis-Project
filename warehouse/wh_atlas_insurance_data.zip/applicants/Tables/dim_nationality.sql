CREATE TABLE [applicants].[dim_nationality] (

	[nationality_sk] bigint NULL, 
	[country] varchar(max) NULL, 
	[load_timestamp] datetime2(6) NOT NULL
);