CREATE TABLE [applicants].[dim_banking] (

	[banking_sk] bigint NULL, 
	[applicant_id] varchar(max) NULL, 
	[bank_name] varchar(max) NULL, 
	[is_current] bigint NULL, 
	[load_timestamp] datetime2(6) NOT NULL
);