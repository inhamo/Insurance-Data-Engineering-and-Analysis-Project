CREATE TABLE [applicants].[dim_demographic] (

	[demographic_sk] bigint NULL, 
	[ethnicity] varchar(max) NULL, 
	[load_timestamp] datetime2(6) NOT NULL
);