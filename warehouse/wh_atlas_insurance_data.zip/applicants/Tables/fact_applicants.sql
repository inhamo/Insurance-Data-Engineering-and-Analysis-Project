CREATE TABLE [applicants].[fact_applicants] (

	[applicant_id] varchar(max) NULL, 
	[gender] varchar(max) NULL, 
	[Age] bigint NULL, 
	[date_of_birth] date NULL, 
	[proof_of_address_document] varchar(max) NULL, 
	[applicant_sk] bigint NULL, 
	[demographic_sk] bigint NULL, 
	[nationality_sk] bigint NULL, 
	[load_timestamp] datetime2(6) NOT NULL
);