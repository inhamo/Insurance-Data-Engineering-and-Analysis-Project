CREATE TABLE [applicants].[dim_health] (

	[health_sk] bigint NULL, 
	[applicant_id] varchar(max) NULL, 
	[is_current_smoker] varchar(max) NULL, 
	[no_of_smoking_years] bigint NULL, 
	[is_previous_smoker] varchar(max) NULL, 
	[years_since_quit_smoking] float NULL, 
	[alcohol_usage] varchar(max) NULL, 
	[alcohol_units_per_week] bigint NULL, 
	[is_on_long_term_medication] varchar(max) NULL, 
	[no_of_years_on_medication] float NULL, 
	[dual_substance_use] varchar(max) NULL, 
	[smoker_category] varchar(max) NULL, 
	[quit_success_score] varchar(max) NULL, 
	[load_timestamp] datetime2(6) NOT NULL
);