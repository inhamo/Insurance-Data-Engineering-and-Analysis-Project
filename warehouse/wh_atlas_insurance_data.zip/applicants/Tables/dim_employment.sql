CREATE TABLE [applicants].[dim_employment] (

	[employment_sk] bigint NULL, 
	[applicant_id] varchar(max) NULL, 
	[job_title] varchar(max) NULL, 
	[monthly_income_zar] bigint NULL, 
	[owned_assets_value_zar] bigint NULL, 
	[owned_debt_value_zar] bigint NULL, 
	[credit_score] bigint NULL, 
	[is_current] bigint NULL, 
	[load_timestamp] datetime2(6) NOT NULL
);