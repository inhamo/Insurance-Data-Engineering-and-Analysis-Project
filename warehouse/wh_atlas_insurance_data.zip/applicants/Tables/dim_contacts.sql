CREATE TABLE [applicants].[dim_contacts] (

	[contact_sk] bigint NULL, 
	[applicant_id] varchar(max) NULL, 
	[contact_type] varchar(max) NULL, 
	[is_current] bigint NULL, 
	[load_timestamp] datetime2(6) NOT NULL
);