CREATE TABLE [premiums].[fact_payment_history] (

	[payment_id] varchar(max) NULL, 
	[policy_number] varchar(max) NULL, 
	[payment_date] date NULL, 
	[amount_paid] bigint NULL, 
	[payment_method] varchar(max) NULL, 
	[load_timestamp] datetime2(6) NOT NULL
);