CREATE TABLE [dbo].[dim_date_table] (

	[Date] date NULL, 
	[Year] int NULL, 
	[Quarter] int NULL, 
	[QuarterName] varchar(max) NOT NULL, 
	[Month] int NULL, 
	[MonthName] varchar(max) NULL, 
	[WeekNumber] int NULL, 
	[Day] int NULL, 
	[DayOfWeek] int NULL, 
	[DayName] varchar(max) NULL, 
	[DayOfYear] int NULL, 
	[YearMonth] varchar(max) NULL, 
	[MonthYear] varchar(max) NULL, 
	[IsWeekend] bit NOT NULL, 
	[IsWorkingDay] bit NOT NULL, 
	[IsLastDayOfMonth] bit NOT NULL, 
	[FiscalYear] int NULL, 
	[FiscalQuarter] int NOT NULL, 
	[DateKey] int NULL, 
	[CreatedDate] datetime2(6) NOT NULL, 
	[LastUpdated] datetime2(6) NOT NULL
);