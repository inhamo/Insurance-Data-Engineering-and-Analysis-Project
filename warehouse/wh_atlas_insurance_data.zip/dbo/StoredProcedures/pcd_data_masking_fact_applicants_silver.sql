CREATE   PROCEDURE pcd_data_masking_fact_applicants_silver
AS
BEGIN
    DECLARE @LakehouseDB VARCHAR(100) = 'lk_atlas_insurance_data_SILVER';
    
    -- Applicants fact data masking
    EXEC('
        USE [' + @LakehouseDB + '];
        ALTER TABLE [dbo].[fact_applicants]
        ALTER COLUMN full_name 
        ADD MASKED WITH (FUNCTION = ''default()'')
    ');

    EXEC('
        USE [' + @LakehouseDB + '];
        ALTER TABLE [dbo].[fact_applicants]
        ALTER COLUMN id_number 
        ADD MASKED WITH (FUNCTION = ''partial(2,"XXX-XXX-XXX",2)'')
    ');

    -- Contacts data masking
    EXEC('
        USE [' + @LakehouseDB + '];
        ALTER TABLE [dbo].[applicants_contacts]
        ALTER COLUMN contact 
        ADD MASKED WITH (FUNCTION = ''default()'')
    ');

    -- Banking data masking (fixed syntax)
    EXEC('
        USE [' + @LakehouseDB + '];
        ALTER TABLE [dbo].[applicants_banking]
        ALTER COLUMN bank_account_number
        ADD MASKED WITH (FUNCTION = ''default()'')
    ');
    
    PRINT 'Data masking applied to Lakehouse: ' + @LakehouseDB;
END;