CREATE   PROCEDURE pcd_cls_wh_atlas_insurance_data_silver
AS
BEGIN

    DECLARE @LakehouseDB VARCHAR(100) = 'lk_atlas_insurance_data_SILVER';

    -- WAREHOUSE 
-- Apply column level security
    EXEC
    (
        '
            USE [' + @LakehouseDB + '];
            DENY SELECT ON wh_atlas_insurance_data.applicants.fact_applicants(full_name, id_number) TO [Nomusa@takueinnogmail.onmicrosoft.com]
            DENY SELECT ON wh_atlas_insurance_data.applicants.fact_applicants(full_name, id_number) TO [nolwazi@takueinnogmail.onmicrosoft.com]
        '
    );

    -- Applicants banking
    EXEC
    (
        '
            USE [' + @LakehouseDB + '];
            DENY SELECT ON wh_atlas_insurance_data.applicants.applicants_banking(bank_account_number) TO [Nomusa@takueinnogmail.onmicrosoft.com]
            DENY SELECT ON wh_atlas_insurance_data.applicants.applicants_banking(bank_account_number) TO [nolwazi@takueinnogmail.onmicrosoft.com]
        '
    );

    -- Applicants contacts
    EXEC
    (
        '
            USE [' + @LakehouseDB + '];
            DENY SELECT ON wh_atlas_insurance_data.applicants.applicants_contacts(contact) TO [Nomusa@takueinnogmail.onmicrosoft.com]
            DENY SELECT ON wh_atlas_insurance_data.applicants.applicants_contacts(contact) TO [nolwazi@takueinnogmail.onmicrosoft.com]
        '
    );

    -- Grant relevant data
    EXEC
    (
        '
            USE [' + @LakehouseDB + ']; 
            GRANT SELECT ON wh_atlas_insurance_data.applicants.fact_applicants (applicant_sk, applicant_id, gender, age, date_of_birth, 
            proof_of_address_document, demographic_sk, nationality_sk) TO [Nomusa@takueinnogmail.onmicrosoft.com]
            GRANT SELECT ON wh_atlas_insurance_data.applicants.fact_applicants (applicant_sk, applicant_id, gender, age, date_of_birth, 
            proof_of_address_document, demographic_sk, nationality_sk) TO [nolwazi@takueinnogmail.onmicrosoft.com];
        '
    );

    -- Grant relevant data
    EXEC
    (
        '
            USE [' + @LakehouseDB + ']; 
            GRANT SELECT ON wh_atlas_insurance_data.applicants.applicants_banking (banking_sk, applicant_id, bank_name) TO [Nomusa@takueinnogmail.onmicrosoft.com]
            GRANT SELECT ON wh_atlas_insurance_data.applicants.applicants_banking (banking_sk, applicant_id, bank_name) TO [nolwazi@takueinnogmail.onmicrosoft.com];
        '
    )

    EXEC
    (
        '
            USE [' + @LakehouseDB + ']; 
            GRANT SELECT ON wh_atlas_insurance_data.applicants.applicants_contacts (contact_sk, applicant_id, contact_type, 
            is_current) TO [Nomusa@takueinnogmail.onmicrosoft.com]
            GRANT SELECT ON wh_atlas_insurance_data.applicants.applicants_contacts (contact_sk, applicant_id, contact_type, 
            is_current) TO [nolwazi@takueinnogmail.onmicrosoft.com];
        '
    )
END;