CREATE TABLE [policies].[dim_reinsurance_companies] (

	[reinsurance_company] varchar(max) NULL, 
	[reinsurance_company_sk] bigint NULL, 
	[load_timestamp] datetime2(6) NOT NULL
);