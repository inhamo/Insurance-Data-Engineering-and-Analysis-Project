CREATE TABLE [policies].[fact_policies] (

	[policy_sk] bigint NULL, 
	[policy_type] varchar(max) NULL, 
	[policy_sub_type] varchar(max) NULL, 
	[load_timestamp] datetime2(6) NOT NULL
);