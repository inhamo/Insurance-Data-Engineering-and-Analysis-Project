CREATE TABLE [policies].[dim_agents] (

	[agent_name] varchar(max) NULL, 
	[agent_sk] bigint NULL, 
	[load_timestamp] datetime2(6) NOT NULL
);