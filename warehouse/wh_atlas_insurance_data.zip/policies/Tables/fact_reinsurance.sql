CREATE TABLE [policies].[fact_reinsurance] (

	[policy_number] varchar(max) NULL, 
	[has_excess_of_loss] bigint NULL, 
	[is_reinsured] bigint NULL, 
	[reinsurance_share] float NULL, 
	[excess_of_loss_retention_amount] float NULL, 
	[reinsurance_type] varchar(max) NULL, 
	[reinsurance_company_sk] bigint NULL, 
	[load_timestamp] datetime2(6) NOT NULL
);