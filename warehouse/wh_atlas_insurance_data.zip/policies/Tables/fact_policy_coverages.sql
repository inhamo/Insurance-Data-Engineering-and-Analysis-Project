CREATE TABLE [policies].[fact_policy_coverages] (

	[policy_number] varchar(max) NULL, 
	[applicant_id] varchar(max) NULL, 
	[coverage] bigint NULL, 
	[premium] bigint NULL, 
	[deductible] int NULL, 
	[exposure_amount] float NULL, 
	[load_timestamp] datetime2(6) NOT NULL
);