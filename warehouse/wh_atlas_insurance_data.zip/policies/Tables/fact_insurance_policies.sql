CREATE TABLE [policies].[fact_insurance_policies] (

	[policy_number] varchar(max) NULL, 
	[applicant_id] varchar(max) NULL, 
	[channel] varchar(max) NULL, 
	[risk_factor] float NULL, 
	[discount_percentage] float NULL, 
	[payment_frequency] varchar(max) NULL, 
	[policy_sk] bigint NULL, 
	[agent_sk] bigint NULL, 
	[load_timestamp] datetime2(6) NOT NULL
);