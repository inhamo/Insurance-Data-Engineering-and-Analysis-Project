CREATE TABLE [policies].[dim_policies_dates] (

	[policy_number] varchar(max) NULL, 
	[effective_date] date NULL, 
	[expiration_date] date NULL, 
	[renewal_notice_date] date NULL, 
	[policy_tenure_days] bigint NULL, 
	[renewal_days_before_expiration] bigint NULL, 
	[load_timestamp] datetime2(6) NOT NULL
);