CREATE TABLE [claims].[fact_claims] (

	[claim_id] varchar(max) NULL, 
	[policy_number] varchar(max) NULL, 
	[claim_type] varchar(max) NULL, 
	[claim_amount] bigint NULL, 
	[date_of_claim] date NULL, 
	[claim_handler] varchar(max) NULL, 
	[load_timestamp] datetime2(6) NOT NULL
);