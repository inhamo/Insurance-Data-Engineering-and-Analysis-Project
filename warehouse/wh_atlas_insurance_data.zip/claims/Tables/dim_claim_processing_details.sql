CREATE TABLE [claims].[dim_claim_processing_details] (

	[claim_id] varchar(max) NULL, 
	[claim_status] varchar(max) NULL, 
	[settlement_amount] float NULL, 
	[date_of_settlement] date NULL, 
	[processing_days] bigint NULL, 
	[complexity_level] varchar(max) NULL, 
	[documentation_status] varchar(max) NULL, 
	[load_timestamp] datetime2(6) NOT NULL
);